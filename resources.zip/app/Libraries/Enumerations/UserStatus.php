<?php
namespace App\Libraries\Enumerations;

class UserStatus
{
    
    public static $ACTIVE = 0;
    public static $INACTIVE = 1;
   
}