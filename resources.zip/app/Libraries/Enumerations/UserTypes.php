<?php
namespace App\Libraries\Enumerations;

class UserTypes
{

    public static $CLINICIAN = 3;
    public static $PATIENT = 4;
    
}