<?php
namespace App\Libraries\Enumerations;

class UserGender
{
    public static $MALE = 0;
    public static $FEMALE = 1;
     public static $OTHER = 2;
      public static $PREFER_NOT_TO_SAY = 3;
   
}