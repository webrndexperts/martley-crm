<footer>
    <div class="pull-right">
        {{ config('app.name') }}
    </div>
    <div class="clearfix"></div>
</footer>